
# Escultura 3D — Visor web con <model-viewer>

Este paquete incluye:
- `index.html`: página lista para ver y manipular el modelo 3D (rotar, zoom, AR).
- `escultura.glb`: tu archivo 3D.
- `qr_placeholder.png`: QR con una URL de ejemplo (cámbiala por tu URL real al publicar).

## Cómo publicarlo gratis (dos opciones)

### Opción A: GitHub Pages (100% gratis)
1. Crea un repositorio llamado, por ejemplo, `escultura`.
2. Sube los archivos `index.html` y `escultura.glb` al repositorio (carpeta raíz).
3. En **Settings → Pages**, selecciona **Source: GitHub Actions** o **Deploy from a branch** (main/root), guarda.
4. La web quedará en `https://TU_USUARIO.github.io/escultura/` (ajusta TU_USUARIO).
5. Genera el QR con esa URL final.

### Opción B: Netlify (muy simple)
1. Entra a https://app.netlify.com/ y crea cuenta.
2. Arrastra y suelta esta carpeta al panel de **Deploys**.
3. Netlify te dará una URL del tipo `https://nombre-aleatorio.netlify.app/`. Puedes personalizarla.
4. Genera el QR con esa URL final.

## Regenerar el QR
- Abre un generador de QR (ej. https://www.qrcode-monkey.com/ o https://goqr.me/).
- Pega tu URL final (por ejemplo, `https://TU_USUARIO.github.io/escultura/`) y exporta en **SVG** o **PNG**.
- Sustituye `qr_placeholder.png` si quieres.

## Consejos
- Formato recomendado: GLB/GLTF (ligero y compatible).
- Si AR no funciona en tu dispositivo, igualmente verás el modelo 3D manipulable en el navegador.
- Prueba en varios móviles y redes. Añade un texto junto al QR: “Escanea → rota con un dedo · zoom con pellizco”.
